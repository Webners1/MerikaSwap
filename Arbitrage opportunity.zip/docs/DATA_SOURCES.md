# Data sources

- Graph
- Covalent
- Web3
- Next big thing...

## Adding new data sources

1. Add folder to fetchers with the name of the data source and define fetchers.
2. Add folder to services with the name of the data source and define hooks.