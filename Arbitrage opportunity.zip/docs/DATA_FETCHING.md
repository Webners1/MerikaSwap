# Data Fetching

https://swr.vercel.app/