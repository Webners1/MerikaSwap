import { X } from 'react-feather'

// @ts-ignore TYPE NEEDS FIXING
const CloseIcon = (props) => <X className="cursor-pointer" {...props} />

export default CloseIcon
